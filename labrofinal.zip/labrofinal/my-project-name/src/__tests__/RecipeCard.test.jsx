import { render, screen } from '@testing-library/react';
import RecipeCard from '../components/RecipeCard';
import { BrowserRouter } from 'react-router-dom';
import { AppProvider } from '../context/AppContext';

test('renders card with title', () => {
  const meal = { idMeal: '1', strMeal: 'Test Meal', strMealThumb: 'https://via.placeholder.com/150', strArea: 'Ukr', strCategory: 'Main' };
  render(
    <AppProvider>
      <BrowserRouter>
        <RecipeCard meal={meal} />
      </BrowserRouter>
    </AppProvider>
  );
  expect(screen.getByText('Test Meal')).toBeInTheDocument();
});