import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import RecipeDetails from './pages/RecipeDetails';
import Favorites from './pages/Favorites';
import ShoppingList from './pages/ShoppingList';
import Checkout from './pages/Checkout';

export default function App() {
  return (
    <>
      <Navbar />
      <main>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/recipe/:id" element={<RecipeDetails/>}/>
          <Route path="/favorites" element={<Favorites/>}/>
          <Route path="/shopping" element={<ShoppingList/>}/>
          <Route path="/checkout" element={<Checkout/>}/>
          <Route path="*" element={<h2>404</h2>} />
        </Routes>
      </main>
    </>
  );
}