import { useState } from 'react';

export default function SearchBar({ onSearch, initial='' }) {
  const [q, setQ] = useState(initial);
  return (
    <form onSubmit={e => {e.preventDefault(); onSearch(q);}} className="search">
      <input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Шукати..." />
      <button>Пошук</button>
    </form>
  );
}