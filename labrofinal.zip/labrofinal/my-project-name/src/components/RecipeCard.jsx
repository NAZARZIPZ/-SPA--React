import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';

export default function RecipeCard({ meal }) {
  const { favorites, toggleFavorite } = useApp();
  const isFav = favorites.some(x => x.idMeal === meal.idMeal);

  return (
    <div className="card">
      <img src={meal.strMealThumb} />
      <h3>{meal.strMeal}</h3>
      <p>{meal.strArea} • {meal.strCategory}</p>
      <div className="card-actions">
        <Link to={`/recipe/${meal.idMeal}`}>Деталі</Link>
        <button onClick={()=>toggleFavorite(meal)}>
          {isFav ? 'Убрати' : 'В обране'}
        </button>
      </div>
    </div>
  );
}