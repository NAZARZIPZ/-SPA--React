import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';

export default function Navbar() {
  const { favorites, shopping } = useApp();
  return (
    <nav className="nav">
      <Link to="/" className="brand">Recipe Finder</Link>
      <div className="nav-right">
        <Link to="/favorites">Обране ({favorites.length})</Link>
        <Link to="/shopping">Список ({shopping.length})</Link>
        <Link to="/checkout">Оформлення</Link>
      </div>
    </nav>
  );
}