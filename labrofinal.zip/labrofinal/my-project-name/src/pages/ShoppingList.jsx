import { useApp } from '../context/AppContext';

export default function ShoppingList() {
  const { shopping, remove, clear } = useApp();
  return (
    <div>
      <h2>Список</h2>
      <ul>
        {shopping.map((x, i) => (
          <li key={i}>{x} <button onClick={()=>remove(i)}>X</button></li>
        ))}
      </ul>
      {shopping.length > 0 && <button onClick={clear}>Очистити</button>}
    </div>
  );
}