import { useEffect, useState } from 'react';
import SearchBar from '../components/SearchBar';
import RecipeCard from '../components/RecipeCard';
import Loading from '../components/Loading';
import { searchMeals } from '../api';

export default function Home() {
  const [query, setQuery] = useState('chicken');
  const [meals, setMeals] = useState([]);
  const [loading, setLoading] = useState(false);

  const go = async (q) => {
    setLoading(true);
    setMeals(await searchMeals(q));
    setLoading(false);
  };

  useEffect(() => { go(query); }, []);

  return (
    <div>
      <h1>Пошук</h1>
      <SearchBar onSearch={go} initial={query} />
      {loading ? <Loading/> :
        <div className="grid">
          {meals.length === 0 ? <p>Нічого нема</p> :
            meals.map(m => <RecipeCard key={m.idMeal} meal={m}/>)
          }
        </div>
      }
    </div>
  );
}