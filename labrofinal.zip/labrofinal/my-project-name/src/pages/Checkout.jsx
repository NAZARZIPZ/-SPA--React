import { useState } from 'react';
import { useApp } from '../context/AppContext';

export default function Checkout() {
  const { shopping, clear } = useApp();
  const [name, setName] = useState('');
  const [addr, setAddr] = useState('');
  const [err, setErr] = useState('');

  const submit = (e) => {
    e.preventDefault();
    if (!name || !addr || shopping.length === 0) return setErr('Заповніть усе.');
    alert('Замовлено!');
    clear();
    setName(''); setAddr(''); setErr('');
  };

  return (
    <form onSubmit={submit} className="form">
      <h2>Оформлення</h2>
      <input placeholder="Імʼя" value={name} onChange={e=>setName(e.target.value)}/>
      <input placeholder="Адреса" value={addr} onChange={e=>setAddr(e.target.value)}/>
      {err && <p className="error">{err}</p>}
      <button>Підтвердити</button>
    </form>
  );
}