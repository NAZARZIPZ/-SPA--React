import { useApp } from '../context/AppContext';
import { Link } from 'react-router-dom';

export default function Favorites() {
  const { favorites, toggleFavorite } = useApp();
  return (
    <div>
      <h2>Обране</h2>
      <div className="grid">
        {favorites.map(m => (
          <div className="card" key={m.idMeal}>
            <img src={m.strMealThumb}/>
            <h3>{m.strMeal}</h3>
            <div className="card-actions">
              <Link to={`/recipe/${m.idMeal}`}>Деталі</Link>
              <button onClick={()=>toggleFavorite(m)}>Убрати</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}