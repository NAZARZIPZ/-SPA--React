import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { lookupMealById } from '../api';
import { useApp } from '../context/AppContext';
import Loading from '../components/Loading';

export default function RecipeDetails() {
  const { id } = useParams();
  const [meal, setMeal] = useState(null);
  const { add } = useApp();
  const [load, setLoad] = useState(true);

  useEffect(() => {
    lookupMealById(id).then(m => {
      setMeal(m);
      setLoad(false);
    });
  }, [id]);

  if (load) return <Loading/>;
  if (!meal) return <p>Не знайдено.</p>;

  const ing = [];
  for (let i=1;i<=20;i++) {
    const a = meal[`strIngredient${i}`];
    const b = meal[`strMeasure${i}`];
    if (a) ing.push(`${a} — ${b}`);
  }

  return (
    <div>
      <h2>{meal.strMeal}</h2>
      <img src={meal.strMealThumb} style={{maxWidth:280}} />
      <ul>
        {ing.map((x, i) => (
          <li key={i}>{x} <button onClick={()=>add(x)}>+ Список</button></li>
        ))}
      </ul>
      <p>{meal.strInstructions}</p>
    </div>
  );
}