const API = 'https://www.themealdb.com/api/json/v1/1';

export async function searchMeals(q) {
  const res = await fetch(`${API}/search.php?s=${q}`);
  const data = await res.json();
  return data.meals || [];
}

export async function lookupMealById(id) {
  const res = await fetch(`${API}/lookup.php?i=${id}`);
  const data = await res.json();
  return data.meals ? data.meals[0] : null;
}