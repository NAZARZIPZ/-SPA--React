import { createContext, useContext, useState, useEffect } from 'react';

const Ctx = createContext();

export function AppProvider({ children }) {
  const [favorites, setFavorites] = useState(() =>
    JSON.parse(localStorage.getItem('fav') || '[]')
  );
  const [shopping, setShopping] = useState(() =>
    JSON.parse(localStorage.getItem('shop') || '[]')
  );

  useEffect(() => localStorage.setItem('fav', JSON.stringify(favorites)), [favorites]);
  useEffect(() => localStorage.setItem('shop', JSON.stringify(shopping)), [shopping]);

  const toggleFavorite = (m) =>
    setFavorites((prev) =>
      prev.some(x => x.idMeal === m.idMeal)
        ? prev.filter(x => x.idMeal !== m.idMeal)
        : [...prev, m]
    );

  return (
    <Ctx.Provider value={{
      favorites, toggleFavorite,
      shopping,
      add: (i) => setShopping([...shopping, i]),
      remove: (i) => setShopping(shopping.filter((_, idx) => idx !== i)),
      clear: () => setShopping([])
    }}>
      {children}
    </Ctx.Provider>
  );
}

export const useApp = () => useContext(Ctx);